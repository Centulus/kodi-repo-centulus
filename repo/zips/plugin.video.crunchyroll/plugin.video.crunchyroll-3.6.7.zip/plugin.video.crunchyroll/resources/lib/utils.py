# -*- coding: utf-8 -*-
# Crunchyroll
# Copyright (C) 2023 smirgol
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
import json
import re
import asyncio
from datetime import datetime
from json import dumps
from typing import Dict, Union, List, Optional

import requests
import xbmc
import xbmcgui
import xbmcvfs

from .globals import G
from .model import CrunchyrollError, ListableItem, EpisodeData, MovieData, SeriesData, SeasonData


# @todo we could change the return type and along with the listables return additional data that we preload
#       like info what is on watchlist, artwork, playhead, ...
#       for that we should use async requests (asyncio)
def get_listables_from_response(data: Optional[List[dict]]) -> List[ListableItem]:
    """ takes an API response object, determines type of its contents and creates DTOs for further processing
    Safely handles None or unexpected input by returning an empty list.
    """

    listable_items: List[ListableItem] = []

    if not data or not isinstance(data, list):
        # Guard against None or unexpected shapes
        return listable_items

    for item in data:
        # fetch type, which is always somewhere else, depending on api endpoint *sighs*
        item_type = item.get('panel', {}).get('type') or item.get('type') or item.get('__class__')
        if not item_type:
            crunchy_log(
                "get_listables_from_response | failed to determine type for response item %s" % (
                    json.dumps(item, indent=4)),
                xbmc.LOGERROR
            )
            continue

        if item_type == 'series':
            if not filter_series(item):
                continue
            listable_items.append(SeriesData(item))
        elif item_type == 'season':
            # filter series items based on language settings
            if not filter_seasons(item):
                continue
            listable_items.append(SeasonData(item))
        elif item_type == 'episode':
            listable_items.append(EpisodeData(item))
        elif item_type == 'movie':
            listable_items.append(MovieData(item))
        else:
            crunchy_log(
                "get_listables_from_response | unhandled index for metadata. %s" % (json.dumps(item, indent=4)),
                xbmc.LOGERROR
            )
            continue

    return listable_items


# Compatibility wrapper for asyncio.to_thread (added in Python 3.9)
# Falls back to running the callable in the default executor on older Python versions (e.g., 3.8)
async def aio_to_thread(func, /, *args, **kwargs):
    """Run a blocking callable in a thread and await its result, Python 3.8+ compatible.

    Uses asyncio.to_thread when available (3.9+), otherwise run_in_executor.
    """
    try:
        to_thread = getattr(asyncio, "to_thread")
    except Exception:
        to_thread = None

    if callable(to_thread):
        return await to_thread(func, *args, **kwargs)

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, lambda: func(*args, **kwargs))


def get_episodes_for_season(season_id: str) -> List[EpisodeData]:
    """ fetch all episodes of a season in a single request, in API order """

    req = G.api.make_request(
        method="GET",
        url=G.api.EPISODES_ENDPOINT.format(G.api.account_data.cms.bucket),
        params={
            "locale": G.args.subtitle,
            "season_id": season_id
        },
        timeout=15
    )

    if not req or "error" in req:
        return []

    return [item for item in get_listables_from_response(req.get('items')) if isinstance(item, EpisodeData)]


async def get_cms_object_data_by_ids(ids: list) -> dict:
    """ fetch info from api object endpoint for given ids. Useful to complement missing data """

    # filter out entries with no value
    ids_filtered = [item for item in ids if item != 0 and item is not None]
    if len(ids_filtered) == 0:
        return {}

    try:
        # Offload blocking request into a thread to avoid freezing event loop
        req = await aio_to_thread(
            G.api.make_request,
            'GET',
            G.api.OBJECTS_BY_ID_LIST_ENDPOINT.format(','.join(ids_filtered)),
            None,
            {
                'locale': G.args.subtitle,
                'ratings': 'true'
            },
            None,
            None,
            False,
            20
        )
    except (CrunchyrollError, requests.exceptions.RequestException):
        crunchy_log("get_cms_object_data_by_ids: failed to load for: %s" % ",".join(ids_filtered))
        return {}

    if not req or 'error' in req:
        return {}

    return {item.get('id'): item for item in req.get('data')}


def get_stream_id_from_item(item: Dict) -> Union[str, None]:
    """ takes a URL string and extracts the stream ID from it """

    pattern = '/videos/([^/]+)/streams'
    stream_id = re.search(pattern, item.get('__links__', {}).get('streams', {}).get('href', ''))
    # history data has the stream_id at a different location
    if not stream_id:
        stream_id = re.search(pattern, item.get('streams_link', ''))

    if not stream_id:
        raise CrunchyrollError('Failed to get stream id')

    return stream_id[1]


async def get_playheads_from_api(episode_ids: Union[str, list]) -> Dict:
    """ Retrieve playhead data from API for given episode / movie ids """

    if isinstance(episode_ids, str):
        episode_ids = [episode_ids]

    # Offload blocking request into a thread to avoid freezing event loop
    response = await aio_to_thread(
        G.api.make_request,
        'GET',
        G.api.PLAYHEADS_ENDPOINT.format(G.api.account_data.account_id),
        None,
        {
            'locale': G.args.subtitle,
            'content_ids': ','.join(episode_ids)
        },
        None,
        None,
        False,
        15
    )

    out = {}

    if not response:
        return out

    # prepare by id
    for item in response.get('data'):
        out[item.get('content_id')] = {
            'playhead': item.get('playhead'),
            'fully_watched': item.get('fully_watched')
        }

    return out


async def get_watchlist_status_from_api(ids: list) -> list:
    """ retrieve watchlist status for given media ids """

    # Offload blocking request into a thread to avoid freezing event loop
    req = await aio_to_thread(
        G.api.make_request,
        'GET',
        G.api.WATCHLIST_V2_ENDPOINT.format(G.api.account_data.account_id),
        None,
        {
            "content_ids": ','.join(ids),
            "locale": G.args.subtitle
        },
        None,
        None,
        False,
        15
    )

    if not req or req.get("error") is not None:
        crunchy_log("get_in_queue: Failed to retrieve data", xbmc.LOGERROR)
        return []

    if not req.get('data'):
        return []

    return [item.get('id') for item in req.get('data')]


def get_img_from_static(image, image_type='normal') -> Optional[str]:
    if image is None:
        return None

    path = G.api.STATIC_IMG_PROFILE

    if image_type == "wallpaper":
        path = G.api.STATIC_WALLPAPER_PROFILE

    return path + image


def get_img_from_struct(item: Dict, image_type: str, depth: int = 2) -> Union[str, None]:
    """ dive into API info structure and extract requested image from its struct """

    # @todo: add option to specify quality / max size
    images = item.get("images") or {}
    seq = images.get(image_type) or []
    # Expect a nested list structure like [[{source:...}, ...], ...]
    if isinstance(seq, list) and seq:
        src = seq
        for _ in range(0, depth):
            # Ensure current level is a non-empty list before indexing
            if isinstance(src, list) and src:
                src = src[-1]
            else:
                return None
        # Final level should be a dict with 'source'
        if isinstance(src, dict) and src.get('source'):
            return src.get('source')

    return None


def dump(data) -> None:
    xbmc.log(dumps(data, indent=4), xbmc.LOGINFO)


def log(message) -> None:
    xbmc.log(message, xbmc.LOGINFO)


def crunchy_log(message, loglevel=xbmc.LOGINFO) -> None:
    """Central logging helper.

    - Silences logs when global shutdown is requested (G.noop_logging).
    - Avoids logging from non-main threads to reduce risks during teardown on Python 3.8/Windows.
    """
    try:
        if getattr(G, 'noop_logging', False):
            return
        import threading
        if threading.current_thread().name != 'MainThread':
            return
    except Exception:
        pass
    addon_name = G.args.addon_name if G.args is not None and hasattr(G.args, 'addon_name') else "Crunchyroll"
    xbmc.log("[PLUGIN] %s: %s" % (addon_name, str(message)), loglevel)


def log_error_with_trace(message, show_notification: bool = True) -> None:
    import sys
    import traceback

    # Get current system exception
    ex_type, ex_value, ex_traceback = sys.exc_info()

    # Extract unformatter stack traces as tuples
    trace_back = traceback.extract_tb(ex_traceback)

    # Format stacktrace
    stack_trace = list()

    for trace in trace_back:
        stack_trace.append(
            "File : %s , Line : %d, Func.Name : %s, Message : %s" % (trace[0], trace[1], trace[2], trace[3]))

    addon_name = G.args.addon_name if G.args is not None and hasattr(G.args, 'addon_name') else "Crunchyroll"

    try:
        if not getattr(G, 'noop_logging', False):
            xbmc.log("[PLUGIN] %s: %s" % (addon_name, str(message)), xbmc.LOGERROR)
            xbmc.log("[PLUGIN] %s: %s %s\n%s" % (addon_name, ex_type.__name__, ex_value, "\n".join(stack_trace)), xbmc.LOGERROR)
            if show_notification:
                xbmcgui.Dialog().notification(
                    '%s Error' % addon_name,
                    'Please check logs for details',
                    xbmcgui.NOTIFICATION_ERROR,
                    5
                )
    except Exception:
        # Swallow any logging/notification errors during teardown
        pass


def ensure_streaming_cache_settings() -> None:
    """Opt-in: give Kodi a larger network cache so a slow/stalling CDN doesn't
    drain the buffer. Writes advancedsettings.xml and asks for a restart only when
    it actually changes something, so it's safe to call on every playback.
    """
    if G.args.addon.getSetting("optimize_cache") != "true":
        return

    from xml.etree import ElementTree as ET

    # ~150 MiB forward buffer, refilled at up to 10x realtime, internet streams only
    wanted = {"buffermode": "1", "memorysize": "157286400", "readfactor": "10"}
    path = xbmcvfs.translatePath("special://profile/advancedsettings.xml")

    try:
        if xbmcvfs.exists(path):
            fh = xbmcvfs.File(path)
            raw = fh.read()
            fh.close()
            root = ET.fromstring(raw) if raw.strip() else ET.Element("advancedsettings")
        else:
            root = ET.Element("advancedsettings")

        if root.tag != "advancedsettings":
            return

        cache = root.find("cache")
        if cache is None:
            cache = ET.SubElement(root, "cache")

        changed = False
        for key, value in wanted.items():
            node = cache.find(key)
            if node is None:
                node = ET.SubElement(cache, key)
            if (node.text or "").strip() != value:
                node.text = value
                changed = True

        if not changed:
            return

        try:
            ET.indent(root)  # Python 3.9+ (Kodi 20+); cosmetic only
        except AttributeError:
            pass
        fh = xbmcvfs.File(path, "w")
        fh.write(ET.tostring(root, encoding="unicode"))
        fh.close()
        xbmcgui.Dialog().notification(
            G.args.addon_name,
            G.args.addon.getLocalizedString(30325),
            xbmcgui.NOTIFICATION_INFO,
            6000
        )
    except Exception as e:
        crunchy_log("ensure_streaming_cache_settings failed: %s" % e, xbmc.LOGWARNING)


def filter_series(seriesItem: Dict) -> bool:
    """ takes an API info struct and returns if it matches user language settings """

    if G.args.addon.getSetting("filter_dubs_by_language") != "true":
        return True

    panel = seriesItem.get('panel') or seriesItem
    item = panel.get("series_metadata") or panel

    # is it a dub in my main language?
    if G.args.addon.getSetting("show_dubs_by_language") == "true":
        if G.args.subtitle in item.get('audio_locales', []):
            return True

    # is it a dub in my alternate language?
    if G.args.addon.getSetting("show_dubs_by_language_fallback") == "true" and G.args.subtitle_fallback and G.args.subtitle_fallback in item.get('audio_locales', []):
        return True

    if G.args.addon.getSetting("show_subs_by_language") == "true":
        # is it japanese audio, but there are subtitles in my main language?
        #
        # edge case for chinese only anime where there is no japanese dub
        # @see: https://github.com/smirgol/plugin.video.crunchyroll/issues/51
        if "ja-JP" in item.get("audio_locales", []) or "zh-CN" in item.get("audio_locales", []):
            # fix for missing subtitles in data
            if item.get("subtitle_locales", []) == [] and item.get('is_subbed', False) is True:
                return True

            if G.args.subtitle in item.get("subtitle_locales", []):
                return True

            if G.args.subtitle_fallback and G.args.subtitle_fallback in item.get("subtitle_locales", []):
                return True

    return False

def filter_seasons(item: Dict) -> bool:
    """ takes an API info struct and returns if it matches user language settings """

    if G.args.addon.getSetting("filter_dubs_by_language") != "true":
        return True

    # is it a dub in my main language?
    if G.args.addon.getSetting("show_dubs_by_language") == "true":
        if G.args.subtitle == item.get('audio_locale', ""):
            return True

    # is it a dub in my alternate language?
    if G.args.addon.getSetting("show_dubs_by_language_fallback") == "true" and G.args.subtitle_fallback and G.args.subtitle_fallback == item.get('audio_locale', ""):
        return True

    if G.args.addon.getSetting("show_subs_by_language") == "true":
        # is it japanese audio, but there are subtitles in my main language?
        #
        # edge case for chinese only anime where there is no japanese dub
        # @see: https://github.com/smirgol/plugin.video.crunchyroll/issues/51
        if item.get("audio_locale") == "ja-JP" or item.get("audio_locale") == "zh-CN":
            # fix for missing subtitles in data
            if item.get("subtitle_locales", []) == [] and item.get('is_subbed', False) is True:
                return True

            if G.args.subtitle in item.get("subtitle_locales", []):
                return True

            if G.args.subtitle_fallback and G.args.subtitle_fallback in item.get("subtitle_locales", []):
                return True

    return False


def format_long_episode_title(season_title: str, episode_number: int, title: str):
    return season_title + " #" + str(episode_number) + " - " + title


def format_short_episode_title(episode_number: int, title: str):
    return two_digits(episode_number) + " - " + title


def two_digits(n: int) -> str:
    if not n:
        return "00"
    if n < 10:
        return "0" + str(n)
    return str(n)


def highlight_list_item_title(list_item: xbmcgui.ListItem):
    """ Highlight title

        Used to highlight that item is already on watchlist
    """
    list_item.setInfo('video', {'title': '[COLOR orange]' + list_item.getLabel() + '[/COLOR]'})


def convert_text_to_date(date_str) -> datetime:
    return datetime.strptime(date_str, "%Y-%m-%d")


def sort_episodes(listables: List[ListableItem]) -> List[ListableItem]:
    """ Sort episodes list to move all unwatched episodes to top """

    watched = []
    unwatched = []

    # split in watched and unwatched
    for listable in listables:
        if not isinstance(listable, EpisodeData) and not isinstance(listable, MovieData):
            crunchy_log('Error sorting episodes. Not an episode nor movie')
            continue

        if listable.playcount == 1:
            watched.append(listable)
        else:
            unwatched.append(listable)

    # sort both lists by aired:
    watched.sort(key=lambda obj: convert_text_to_date(obj.aired), reverse=True)
    unwatched.sort(key=lambda obj: convert_text_to_date(obj.aired), reverse=True)

    return unwatched + watched
