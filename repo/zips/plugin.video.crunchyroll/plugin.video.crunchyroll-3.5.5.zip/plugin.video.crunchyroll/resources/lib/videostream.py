# -*- coding: utf-8 -*-
# Crunchyroll
# Copyright (C) 2023 smirgol
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
import asyncio
import datetime
import os
import sys
from typing import Union, Dict, Optional, Any, List

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib.globals import G
from resources.lib.model import Object, CrunchyrollError, PlayableItem
from resources.lib.utils import log_error_with_trace, crunchy_log, \
    get_playheads_from_api, get_cms_object_data_by_ids, get_listables_from_response, aio_to_thread

# Fix for bug in old python version on Windows when using asyncio.run
# @see: https://github.com/smirgol/plugin.video.crunchyroll/issues/44
# @see: https://stackoverflow.com/questions/63860576/asyncio-event-loop-is-closed-when-using-asyncio-run
if sys.platform == "win32" and sys.version_info >= (3, 8, 0):
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


class VideoPlayerStreamData(Object):
    """ DTO to hold all relevant data for playback """

    def __init__(self):
        self.stream_url: Optional[str] = None
        self.subtitle_urls: Optional[List[str]] = None
        self.skip_events_data: Dict = {}
        self.playheads_data: Dict = {}
        # PlayableItem which is about to be played, that contains cms object data
        self.playable_item: Optional[PlayableItem] = None
        # PlayableItem which contains cms obj data of playable_item's parent, if exists (Episodes, not Movies). currently not used.
        self.playable_item_parent: Optional[PlayableItem] = None
        self.token: Optional[str] = None


class VideoStream(Object):
    """ Build a VideoPlayerStreamData DTO using args.stream_id

    Will download stream details from cr api and store the appropriate stream url

    It will then check if soft subs are enabled in settings and if so, manage downloading the required subtitles, which
    are then renamed to make kodi label them in a readable way - this is because kodi uses the filename of the subtitles
    to identify the language and the cr files have cryptic filenames, which will render gibberish to the user on kodi
    instead of a proper label

    Finally, it will download any existing skip info, which can be used to skip intros / credits / summaries
    """

    def __init__(self, ):
        self.cache_expiration_time: int = 60 * 60 * 24 * 7  # 7 days
        # Ensure base cache directory exists before any listdir/use
        try:
            base_dir = self.get_cache_path()
            xbmcvfs.mkdirs(base_dir)
        except Exception:
            pass
        # cache cleanup
        self._clean_cache_subtitles()

    def get_player_stream_data(self) -> Optional[VideoPlayerStreamData]:
        """ retrieve a VideoPlayerStreamData containing stream url + subtitle urls for playback """

        if not G.args.get_arg('stream_id'):
            return None

        video_player_stream_data = VideoPlayerStreamData()

        crunchy_log("VideoStream: Starting to retrieve data async")
        async_data = asyncio.run(self._gather_async_data())
        crunchy_log("VideoStream: Finished to retrieve data async")

        api_stream_data = async_data.get('stream_data')
        if not api_stream_data:
            raise CrunchyrollError("Failed to fetch stream data from api")

        video_player_stream_data.stream_url = self._get_stream_url_from_api_data_v2(async_data.get('stream_data'))
        video_player_stream_data.subtitle_urls = self._get_subtitles_from_api_data(async_data.get('stream_data'))
        video_player_stream_data.token = async_data.get('stream_data').get('token')

        video_player_stream_data.skip_events_data = async_data.get('skip_events_data')
        video_player_stream_data.playheads_data = async_data.get('playheads_data')
        video_player_stream_data.playable_item = async_data.get('playable_item')
        video_player_stream_data.playable_item_parent = async_data.get('playable_item_parent')

        return video_player_stream_data

    async def _gather_async_data(self) -> Dict[str, Any]:
        """ gather data asynchronously and return them as a dictionary """

        # create threads
        # Use true concurrency by offloading blocking I/O to threads
        t_stream_data = asyncio.create_task(self._get_stream_data_from_api())
        t_skip_events_data = asyncio.create_task(self._get_skip_events(G.args.get_arg('episode_id')))
        t_playheads = asyncio.create_task(get_playheads_from_api(G.args.get_arg('episode_id')))
        t_item_data = asyncio.create_task(
            get_cms_object_data_by_ids([G.args.get_arg('episode_id')]))
        # t_item_parent_data = asyncio.create_task(get_cms_object_data_by_ids(G.args, G.api, G.args.get_arg('series_id')))

        # start async requests and fetch results
        results = await asyncio.gather(t_stream_data, t_skip_events_data, t_playheads, t_item_data)

        cms_obj = results[3].get(G.args.get_arg('episode_id')) if results[3] else None
        playable_item = get_listables_from_response([cms_obj]) if cms_obj else None

        return {
            'stream_data': results[0] or {},
            'skip_events_data': results[1] or {},
            'playheads_data': results[2] or {},
            'playable_item': playable_item[0] if playable_item else None,
            'playable_item_parent': None
            # get_listables_from_response([results[4]])[0] if results[4] else None
        }

    @staticmethod
    async def _get_stream_data_from_api() -> Union[Dict, bool]:
        """Fetch stream data from Crunchyroll playback API using Android TV endpoint."""
        episode_id = G.args.get_arg('episode_id')
        crunchy_log(f"Fetching stream data for episode: {episode_id}")
        crunchy_log(f"Using endpoint: {G.api.STREAMS_ENDPOINT_DRM.format(episode_id)}")

        try:
            # Primary: Android TV playback v2 endpoint via cloudscraper (handles CF)
            # audio param is the audio track locale, not the subtitle locale
            stream_data = await aio_to_thread(
                G.api.request_playback_v2, episode_id, G.api.account_data.default_audio_language
            )

            # Fallback: legacy phone endpoint if ATV fails, returns error, or misses essentials
            if (not stream_data or
                "error" in stream_data or
                not isinstance(stream_data, dict) or
                not stream_data.get('url') or
                not stream_data.get('token')):
                error_msg = stream_data.get('error', 'Unknown error') if stream_data else 'No response'
                crunchy_log(f"ATV playback v2 failed: {error_msg} - trying phone fallback")
                stream_data = await aio_to_thread(G.api.request_playback_phone, episode_id)

            if not stream_data or "error" in stream_data:
                error_msg = stream_data.get('error', 'Unknown error') if stream_data else 'No response'
                crunchy_log(f"Stream data fetch failed after fallback: {error_msg}")

                # Show error dialog and fail playback
                item = xbmcgui.ListItem(G.args.get_arg('title', 'Title not provided'))
                xbmcplugin.setResolvedUrl(int(G.args.argv[1]), False, item)
                xbmcgui.Dialog().ok(G.args.addon_name, G.args.addon.getLocalizedString(30064))
                return False

            crunchy_log("Successfully fetched stream data")
            return stream_data

        except Exception as e:
            crunchy_log(f"Exception during stream data fetch: {e}")
            log_error_with_trace("Stream data fetch failed", False)
            return False

    @staticmethod
    def _get_stream_url_from_api_data_v2(api_data: Dict) -> Union[str, None]:
        """ uses new endpoint to retrieve encryption data along with stream url """

        try:
            if G.args.addon.getSetting("soft_subtitles") == "false":
                url = api_data["hardSubs"]

                if G.args.subtitle in url:
                    url = url[G.args.subtitle]["url"]
                elif G.args.subtitle_fallback in url:
                    url = url[G.args.subtitle_fallback]["url"]
                else:
                    url = api_data["url"]
            else:
                url = api_data["url"]

        except IndexError:
            item = xbmcgui.ListItem(G.args.get_arg('title', 'Title not provided'))
            xbmcplugin.setResolvedUrl(int(G.args.argv[1]), False, item)
            xbmcgui.Dialog().ok(G.args.addon_name, G.args.addon.getLocalizedString(30064))
            return None

        return url

    def _get_subtitles_from_api_data(self, api_stream_data) -> Union[str, None]:
        """ retrieve appropriate subtitle urls from api data, using local caching and renaming """

        # we only need those urls if soft-subs are enabled in addon settings
        if G.args.addon.getSetting("soft_subtitles") == "false":
            return None

        subtitles_data_raw = []
        subtitles_url_cached = []

        subs = (api_stream_data or {}).get("subtitles") or {}
        if isinstance(subs, dict):
            if G.args.subtitle in subs:
                subtitles_data_raw.append(subs.get(G.args.subtitle))
            if G.args.subtitle_fallback and G.args.subtitle_fallback in subs:
                subtitles_data_raw.append(subs.get(G.args.subtitle_fallback))

        if not subtitles_data_raw:
            return None

        # we need to download the subtitles, cache and rename them to show proper labels in the kodi video player
        for subtitle_data in subtitles_data_raw:
            cache_result = self._get_subtitle_from_cache(
                subtitle_data.get('url', ""),
                subtitle_data.get('language', ""),
                subtitle_data.get('format', "")
            )

            if cache_result is not None:
                subtitles_url_cached.append(cache_result)

        return subtitles_url_cached if subtitles_url_cached is not None else None

    def _cache_subtitle(self, subtitle_url: str, subtitle_language: str, subtitle_format: str) -> bool:
        """ cache a subtitle from the given url and rename it for kodi to label it correctly """

        try:
            # api request streams
            subtitles_req = G.api.make_request(
                method="GET",
                url=subtitle_url
            )
        except Exception:
            log_error_with_trace("error in requesting subtitle data from api")
            raise CrunchyrollError(
                "Failed to download subtitle for language %s from url %s" % (subtitle_language, subtitle_url)
            )

        if not subtitles_req.get('data', None):
            # error
            raise CrunchyrollError("Returned data is not text")

        cache_target = xbmcvfs.translatePath(self.get_cache_path() + G.args.get_arg('stream_id') + '/')
        xbmcvfs.mkdirs(cache_target)

        cache_file = self.get_cache_file_name(subtitle_language, subtitle_format)

        with open(cache_target + cache_file, 'w', encoding='utf-8') as file:
            result = file.write(subtitles_req.get('data'))

        return True if result > 0 else False

    def _get_subtitle_from_cache(
            self,
            subtitle_url: str,
            subtitle_language: str,
            subtitle_format: str
    ) -> Union[str, None]:
        """ try to get a subtitle using its url, language info and format either from cache or api """

        if not subtitle_url or not subtitle_language or not subtitle_format:
            crunchy_log("get_subtitle_from_cache: missing argument", xbmc.LOGERROR)
            return None

        # prepare the filename for the subtitles
        cache_file = self.get_cache_file_name(subtitle_language, subtitle_format)

        # build full path to cached file
        cache_target = xbmcvfs.translatePath(self.get_cache_path() + G.args.get_arg('stream_id') + '/') + cache_file

        # check if cached file exists
        if not xbmcvfs.exists(cache_target):
            # download and cache file
            if not self._cache_subtitle(subtitle_url, subtitle_language, subtitle_format):
                # log error
                log_error_with_trace("Failed to write subtitle to cache")
                return None

        cache_file_url = ('special://userdata/addon_data/plugin.video.crunchyroll/cache_subtitles/' +
                          G.args.get_arg('stream_id') +
                          '/' + cache_file)

        return cache_file_url

    def _clean_cache_subtitles(self) -> bool:
        """ clean up all cached subtitles """

        expires = datetime.datetime.now() - datetime.timedelta(seconds=self.cache_expiration_time)

        cache_base_dir = self.get_cache_path()
        try:
            xbmcvfs.mkdirs(cache_base_dir)
        except Exception:
            pass
        dirs, files = xbmcvfs.listdir(cache_base_dir)

        for cache_dir in dirs:
            mtime = datetime.datetime.fromtimestamp(os.path.getmtime(os.path.join(cache_base_dir, cache_dir)))
            if mtime < expires:
                crunchy_log("Cache dir %s is older than 7 days - removing" % os.path.join(cache_base_dir, cache_dir))
                xbmcvfs.rmdir(os.path.join(cache_base_dir, cache_dir) + '/', force=True)

        return True

    @staticmethod
    def get_cache_path() -> str:
        """ return base path for subtitles caching """

        return xbmcvfs.translatePath(G.args.addon.getAddonInfo("profile") + 'cache_subtitles/')

    @staticmethod
    def get_cache_file_name(subtitle_language: str, subtitle_format: str) -> str:
        """ build a file name for the subtitles file that kodi can display with a readable label """

        # kodi ignores the first part of e.g. de-DE - split and use only first part in uppercase
        iso_parts = subtitle_language.split('-')

        filename = xbmcvfs.makeLegalFilename(
            subtitle_language +
            '.' + iso_parts[0] +
            '.' + subtitle_format
        )

        # for some reason, makeLegalFilename likes to append a '/' at the end, effectively making the file a directory
        if filename.endswith('/'):
            filename = filename[:-1]

        # have to use filesystemencoding since filename contains non ascii characters in some language (such as french)
        # and kodi file system encoding can be set to ASCII
        return filename.encode(sys.getfilesystemencoding(), "ignore").decode(sys.getfilesystemencoding())

    @staticmethod
    async def _get_skip_events(episode_id) -> Optional[Dict]:
        """ fetch skip events data from api and return a prepared object for supported skip types if data is valid """

        # if none of the skip options are enabled in setting, don't fetch that data
        if (G.args.addon.getSetting("enable_skip_intro") != "true" and
                G.args.addon.getSetting("enable_skip_credits") != "true"):
            return None

        try:
            crunchy_log("Requesting skip data from %s" % G.api.SKIP_EVENTS_ENDPOINT.format(episode_id))

            # api request streams
            req = G.api.make_unauthenticated_request(
                method="GET",
                url=G.api.SKIP_EVENTS_ENDPOINT.format(episode_id)
            )
        except (requests.exceptions.RequestException, CrunchyrollError):
            try:
                # Some streams raise a 403 on SKIP_EVENTS endpoint but skip data are available in INTRO_V2 endpoint
                intro_req = G.api.make_unauthenticated_request(
                    method="GET",
                    url=G.api.INTRO_V2_ENDPOINT.format(episode_id)
                )
                req = {"intro": {
                    "start": intro_req.get("startTime"),
                    "end": intro_req.get("endTime"),
                }}
            except (requests.exceptions.RequestException, CrunchyrollError):
                # can be okay for e.g. movies, thus only log error, but don't show notification
                crunchy_log(
                    "_get_skip_events: error in requesting skip events data from api. possibly no data available",
                    False
                )
                return None

        if not req or "error" in req:
            crunchy_log("_get_skip_events: error in requesting skip events data from api (2)")
            return None

        # prepare the data a bit
        supported_skips = ['intro', 'credits']
        prepared = dict()
        for skip_type in supported_skips:
            if req.get(skip_type) and req.get(skip_type).get('start') is not None and req.get(skip_type).get(
                    'end') is not None:
                prepared.update({
                    skip_type: dict(start=req.get(skip_type).get('start'), end=req.get(skip_type).get('end'))
                })
                crunchy_log("_get_skip_events: check for %s PASSED" % skip_type, xbmc.LOGINFO)
            else:
                crunchy_log("_get_skip_events: check for %s FAILED" % skip_type, xbmc.LOGINFO)

        if G.args.addon.getSetting("enable_skip_intro") != "true" and prepared.get('intro'):
            prepared.pop('intro', None)

        if G.args.addon.getSetting("enable_skip_credits") != "true" and prepared.get('credits'):
            prepared.pop('credits', None)
        return prepared if len(prepared) > 0 else None
